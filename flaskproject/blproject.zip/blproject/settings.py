
class Config:
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:111111@localhost/lou2"
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    # SQLALCHEMY_ECHO = True
    DEBUG = True